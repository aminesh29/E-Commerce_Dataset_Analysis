POWER BI ASSIGNMENT DATASET
============================

Files:
1. Sales_Raw.csv       - ~250K+ transactional rows with deliberate quality issues and duplicates
2. Customers_Raw.csv   - 12K+ customers with formatting, null, invalid date and duplicate issues
3. Products_Raw.csv    - 800+ products with inconsistent category text, nulls and duplicate products
4. Stores.csv          - store dimension
5. Targets_Raw.csv     - monthly regional targets with inconsistent region labels and duplicates
6. Region_Mapping.csv  - mapping table for standardizing raw region values

Recommended model:
DimCustomer  1:* FactSales
DimProduct   1:* FactSales
DimStore     1:* FactSales
DimDate      1:* FactSales
DimDate      1:* Targets
Region/other dimensions as appropriate

Important:
- The raw files intentionally contain errors. Do NOT pre-clean them before giving them to learners.
- Some issues require business judgement rather than simple deletion.
- Use Power Query for cleaning/transformation and DAX for analytical calculations.
- The target table contains duplicate rows and inconsistent region labels intentionally.
